
const express = require('express');
const Portfolio = require('../models/Portfolio');
const router = express.Router();

// Создание элемента портфолио
router.post('/', async (req, res) => {
  try {
    const { title, description, images } = req.body;
    const newItem = new Portfolio({ title, description, images, createdBy: req.session.userId });
    await newItem.save();
    res.status(201).json(newItem);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create portfolio item' });
  }
});

module.exports = router;
