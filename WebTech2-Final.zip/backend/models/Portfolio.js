
const mongoose = require('mongoose');
const portfolioSchema = new mongoose.Schema({
  title: String,
  description: String,
  images: [String],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
module.exports = mongoose.model('Portfolio', portfolioSchema);
